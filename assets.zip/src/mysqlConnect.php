<?php

$con=mysqli_connect("localhost","root","","conference-master") OR die('Network connection error. Check connection then reload');
 ?>
