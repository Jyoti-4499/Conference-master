<?php
require '../mysqlConnect.php';
?>
<?php
if(isset($_POST['submit'])){
		$rid=mysqli_real_escape_string($con,$_POST['rid']);
		$fname=mysqli_real_escape_string($con,$_POST['fname']);
		$lname=mysqli_real_escape_string($con,$_POST['lname']);
		$phone=mysqli_real_escape_string($con,$_POST['phone']);
		$interest=mysqli_real_escape_string($con,$_POST['interest']);
		$affiliation=mysqli_real_escape_string($con,$_POST['affiliation']);

		// $rid="a";
		// $fname="a";
		// $lname="a";
		// $phone=10;
		// $interest=10;
		// $affiliation=100;

		$insert="INSERT INTO `reviewer` (`rid`, `fname`, `lname`, `phone`, `interest` , `affiliation`) VALUES ('$rid', '$fname', '$lname', '$phone' , '$interest','$affiliation');";
		$run_insert=mysqli_query($con,$insert);
		if($run_insert){
			echo"<script>alert('Details successfully added!')</script>";
			// echo'Details successfully added!';
			echo"<script>window.open('admin.php','_self')</script>";
		}
		else{
			echo"<script>alert('Error 1: Database isn't connected, please try again')</script>";
			// echo "Error 1: Database isn't connected, please try again";
			echo"<script>window.open('add.php','_self')</script>";
		}
}

?>
