<?php
session_start();
require 'src/mysqlConnect.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">

    <title>Admin</title>
		<link rel="icon" href="assets/img/car.png">
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">

  </head>

  <body>

      <!-- Main Content -->
	  <div id="login-page">
	  	<div class="container">

		      <form class="form-login" action="index.php" method="post">
		        <h2 class="form-login-heading">Admin Login</h2>
		        <div class="login-wrap">
		            <input type="text" name="email" class="form-control" placeholder="email" autofocus>
		            <br>
		            <input type="password" name="password"  class="form-control" placeholder="Password">
								<br> <br>
		            <button class="btn btn-theme btn-block" href="index.php" name='admin_login'  type="submit"><i class="fa fa-lock" aria-hidden="true"></i> Sign IN</button>
								<button class="btn btn-theme btn-block" href="src/author/login.php" name='author'  type="submit"><i class="fa fa-lock" aria-hidden="true"></i> Author</button>
								<!-- <button class="btn btn-theme btn-block" href="index.php" name='index'  type="submit"> Home </button> -->
		          <!-- Modal -->
		          <div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="myModal" class="modal fade">
		              <div class="modal-dialog">
		                  <div class="modal-content">
		                      <div class="modal-header">
		                          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

		                      </div>
		                      <!-- <div class="modal-footer">
		                          <button data-dismiss="modal" class="btn btn-default" type="button">Cancel</button>
		                          <button class="btn btn-theme" type="button">Submit</button>
		                      </div> -->
		                  </div>
		              </div>
		          </div>
		          <!-- modal -->
		      </form>

	  	</div>
	  </div>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!--BACKSTRETCH-->
    <!-- You can use an image of whatever size. This script will stretch to fit in any screen size.-->
    <script type="text/javascript" src="assets/js/jquery.backstretch.min.js"></script>
    <script>
        $.backstretch("assets/img/Smp.jpg", {speed: 500});
    </script>
<?php
  if(isset($_POST['admin_login'])){
  $password=mysqli_real_escape_string($con,$_POST['password']);
  $email=mysqli_real_escape_string($con,$_POST['email']);

  $sel="select * from admin where email='$email' AND password='$password'";
  $run=mysqli_query($con,$sel);
  $check=mysqli_num_rows($run);
  if($check==0){
  	echo"<script>alert('Wrong credentials,try again!')</script>";
  	exit();
  }
  else{
  	$_SESSION['email']=$email;
		echo"<script>window.open('src/admin/admin.php','_self')</script>";
		exit();
	 }
	}
	else if(isset($_POST['author'])){
		echo"<script>window.open('src/author/login.php', '_self')</script>";
		exit();
	}
	else if(isset($_POST['index'])){
		echo"<script>window.open('index.php', '_self')</script>";
		exit();
	}
  ?>
  </body>

<footer>
<div style="max-width:500px; margin: 3em auto 0 auto; text-align: center; font-size: 0.85em">
<a rel="license" href="https://creativecommons.org/licenses/by-sa/3.0/"><img alt="Creative Commons License" style="border-width:0;" src="assets/img/cc3.png"/></a><br><a style="color: #000000">This work is licensed under a</a> <a rel="license" href="http://creativecommons.org/licenses/by-sa/3.0/" style="color: #000000">Creative Commons Attribution-ShareAlike 3.0 Unported License</a>
<br>
<p style="color: #000000"><a rel="souce-code" href="https://gitlab.com/software-engg/conference" style="color: #000000" style="bolder"> <b>Get Source Code</b></a> v0.0.6 </p>
</div>
</footer>
</html>
